# Classifier Variable
classifier = None
# Model URL
image_model_url = 'https://teachablemachine.withgoogle.com/models/eTZ6zGEax/'

# Video
video = None
flipped_video = None
# To store the classification
label = ""

# Load the model first
def preload():
    global classifier
    classifier = ml5.image_classifier(image_model_url + 'model.json')

def setup():
    global video, flipped_video
    create_canvas(320, 260)
    # Create the video
    video = create_capture(VIDEO)
    video.size(320, 240)
    video.hide()

    flipped_video = ml5.flip_image(video)
    # Start classifying
    classify_video()

def draw():
    background(0)
    # Draw the video
    image(flipped_video, 0, 0)

    # Draw the label
    fill(255)
    text_size(16)
    text_align(CENTER)
    text(label, width / 2, height - 4)

# Get a prediction for the current video frame
def classify_video():
    global flipped_video
    flipped_video = ml5.flip_image(video)
    classifier.classify(flipped_video, got_result)
    flipped_video.remove()

# When we get a result
def got_result(error, results):
    global label
    # If there is an error
    if error:
        print(error)
        return
    # The results are in an array ordered by confidence.
    # print(results[0])
    label = results[0].label
    # Classifiy again!
    classify_video()
